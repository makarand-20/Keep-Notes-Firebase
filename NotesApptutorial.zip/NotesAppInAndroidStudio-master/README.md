# NotesAppInAndroidStudio

An amazing Android Application with a well designed UI and it has the facility to add, update or delete the note whichever the user want. It shows the randomly different colors on every note whenever the user login or signup for notes application.

First Screen when the user opens the Notes Application- 

![image](https://user-images.githubusercontent.com/64765400/111020731-d523ab00-837c-11eb-9f35-8a1cdceab0c0.png)


Enter your Email and password and login if you have already registered. Otherwise click on New User! Want To Sign In? button and then enter your working email and set a password of at least length of 7.

![image](https://user-images.githubusercontent.com/64765400/111020743-ea003e80-837c-11eb-98ed-608e8394a1ac.png)


User will got the email on the registered email and then verify the email first to use the application. After verification, simply login with your email and password. Then, you will get the below screen- 

![image](https://user-images.githubusercontent.com/64765400/111020754-fb494b00-837c-11eb-94d5-e830f4e54feb.png)


User can also recover the password if the user forgot the password by clicking on forgot password? on the login screen. After clicking, user will be directed to below screen. Here, user can enter the registered mail and easily recover the password using Email-

![image](https://user-images.githubusercontent.com/64765400/111020763-0c925780-837d-11eb-8485-8b3f0c1da96f.png)


Here, you can add as many notes you want by clicking on +(plus) icon and clicking on save icon. 

![image](https://user-images.githubusercontent.com/64765400/111020771-14ea9280-837d-11eb-8aad-53cf6dec83a3.png)

![image](https://user-images.githubusercontent.com/64765400/111020778-22078180-837d-11eb-81fe-ab4f91862de5.png)


You will get the detail of desired note by clicking on that note simply. Here, we can also edit the note if desired. 

When the user click on menu icon which is shown by three dots at the right side of every note then you get the two functions(edit and delete)- 

![image](https://user-images.githubusercontent.com/64765400/111020786-2e8bda00-837d-11eb-868f-a5c3160d1a83.png)


When you click on delete then the particular note is deleted.

If you click on edit then you will move to other screen for editing of note.

![image](https://user-images.githubusercontent.com/64765400/111020797-3cd9f600-837d-11eb-9d3d-8af98bdea6da.png)



If user want to log out from the application then click on three dot menu on the right corner of Action Bar of the notes application-

![image](https://user-images.githubusercontent.com/64765400/111020816-4f542f80-837d-11eb-86ea-5b7713d12ccc.png)


After this, you will be logged out and directed to the login screen. 

Then, you can again login or sign the application if you want. If user enter wrong credentials anywhere then you will got the appropriate toasts everywhere.
Any User Can Sign Anywhere in Any Phone Just by using email and Passwords
